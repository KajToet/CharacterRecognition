var cursorc = document.getElementById("cursorc");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const storage = document.getElementById("storage");
const template = document.createElement("canvas");
const templateCtx = template.getContext("2d");

var cursorDown = false;

const SIZE = 350;

var ppix = new Array();
var pwidth = new Array();

function save() {
	zoom();

	setTimeout(function() {
		var img = ctx.getImageData(0, 0, canvas.width, canvas.height);
		var pix = img.data;

		var pix2 = new Uint8ClampedArray(pix);
		pix2.set(pix);

		ppix.push(pix2);
		pwidth.push(canvas.width);
		storage.innerHTML = ppix.length + " in template";

		setTimeout(clearAll, 1000);
	}, 1000);
}

function clearAll() {
	ctx.beginPath();
	ctx.fillColor = "#000";
        ctx.clearRect(0,0,canvas.width, canvas.height);
	canvas.width = SIZE;
	canvas.height = SIZE;
}

function zoom() {
	var canvas = document.getElementById('canvas');
	var dataUrl = canvas.toDataURL();
	var image = document.createElement('img');
	image.src = dataUrl;
	image.addEventListener("load", () => {

		var width = canvas.width;
		var height = canvas.height;
		var img = ctx.getImageData(0, 0, width, height);
		var pix = img.data;

		var top = 100000, left = 100000, bottom = 100000, right = 100000;
		for (var i = 0, x = 0, y = 0, n = pix.length; i < n; i += 4, x++) {
			if (x >= width) {
				x = 0;
				y++;
			}
			if (pix[i+3] != 0) {
				left = Math.min(left, x);
				right = Math.min(right, width - x - 1);
				top = Math.min(top, y);
				bottom = Math.min(bottom, height - y - 1);
			}
		}

		console.log("l" + left + " r" + right + " t" + top + " b" + bottom);
		var nwidth = width - (right + left);
		var nheight = height - (bottom + top);
		var nas = nwidth / nheight;
		var as = width / height;
		ctx.beginPath();
		ctx.fillColor = "#000";
	        ctx.clearRect(0,0,canvas.width, canvas.height);
		var cwidth = width / as * nas;
		canvas.width = cwidth;
		ctx.drawImage(image, left, top, nwidth, nheight, 0, 0, cwidth, height);
	});
}

function download(){
  var link = document.createElement('a');
  link.download = 'template.png';

  template.width = 0;
  for (var i = 0; i < ppix.length; i++) {
	template.width += pwidth[i];
  }
  template.height = SIZE;
  var img = templateCtx.getImageData(0, 0, template.width, template.height + 1);
  var pix = img.data;

  var space = 0;
  var toggle = false;
  for (var i = 0; i < ppix.length; i++) {
	var p = 0;
	for (var y = 1; y < template.height + 1; y++) {
		for (var x = 0; x < pwidth[i]; x++, p+=4) {
			var p2 = (y * template.width + x + space) * 4;
			pix[p2] = ppix[i][p];
			pix[p2 + 1] = ppix[i][p + 1];
			pix[p2 + 2] = ppix[i][p + 2];
			pix[p2 + 3] = ppix[i][p + 3];
		}
	}
	for (var x = 0; x < pwidth[i]; x++, p+=4) {
		var p2 = (x + space) * 4;
		var val = toggle ? 0 : 255;
		pix[p2] = val;
		pix[p2 + 1] = val;
		pix[p2 + 2] = val;
		pix[p2 + 3] = val;
	}
	toggle = !toggle;
	space += pwidth[i];
  }
  templateCtx.putImageData(img, 0, 0);
  console.log("Template width: " + space);
  link.href = template.toDataURL();
  link.click();
}


let x = 50;
let y = 50;
let px = 50;
let py = 50;
function canvasDraw() {
  // Find center x and y for any partial balls
  function find2ndCenter(pos, max) {
    if (pos < 0) {
      pos = 0;
    }
    else if (pos > max) {
      pos = max;
    }
    else {
      pos = 0;
    }
    return pos;
  }

  function drawBall(x, y) {
    ctx.beginPath();
    ctx.fillColor = "#000";

    ctx.moveTo(x, y); // Move the pen to (30, 50)
    ctx.lineTo(px, py); // Draw a line to (150, 100)
    ctx.stroke()
    px = x;
    py = y;
  }  
  cursorc.style.left = x + "px";
  cursorc.style.top = y + "px";

  const x2 = find2ndCenter(x, canvas.width);
  const y2 = find2ndCenter(y, canvas.height);

  /* Draw the main ball (which may or may not be a full ball) and any
   * partial balls that result from moving close to one of the edges */
  if (cursorDown) drawBall(x, y); // main ball
} // end of function canvasDraw

canvasDraw();

canvas.addEventListener("click", async () => {
  if(!document.pointerLockElement) {
    await canvas.requestPointerLock({
      unadjustedMovement: true,
    });
  }
});

// pointer lock event listeners

document.addEventListener("pointerlockchange", lockChangeAlert, false);

document.addEventListener("keyup", (event) => {
  console.log("Don't draw");
  cursorDown = false;

});

document.addEventListener("keydown", (event) => {
  console.log("Draw");
  cursorDown = true;  
  if (cursorDown) {
    px=x;
    py=y;
  }
});
document.addEventListener("mouseup", (event) => {
  console.log("Don't draw");
  cursorDown = false;

});

document.addEventListener("mousedown", (event) => {
  console.log("Draw");
  cursorDown = true;  
  if (cursorDown) {
    px=x;
    py=y;
  }
});

function lockChangeAlert() {
  if (document.pointerLockElement === canvas) {
    console.log("The pointer lock status is now locked");
    document.addEventListener("mousemove", updatePosition, false);
  } else {
    console.log("The pointer lock status is now unlocked");
    document.removeEventListener("mousemove", updatePosition, false);
  }
}

const tracker = document.getElementById("tracker");

function readBlob() {
	var image = new Image();
	image.onload = function() {
		canvas.width = this.width;
		canvas.height = this.height;
		ctx.drawImage(this, 0, 0);
		var imgData = ctx.getImageData(0,0,this.width,this.height);
		var pix = imgData.data;
		pwidth = new Array();
		var toggle = pix[3];
		var w = 0;
		for (var i = 0, p = 3; i < this.width; w++, i++, p+=4) {
			if (toggle != pix[p]) {
				pwidth.push(w);
				w = 0;
				toggle = pix[p];
			}
		}
		pwidth.push(w);

		console.log(pwidth);

		ppix = new Array();
		var p = 0;
		var start = 0;
		for (var i = 0; i < pwidth.length; i++) {
			w = pwidth[i];

			var imgData = ctx.getImageData(start,1,w,SIZE + 1);
			var pix = imgData.data;
			ppix.push(pix);

			start += w;
		}

		clearAll();
		storage.innerHTML = ppix.length + " in template";
	};
	image.src = window.URL.createObjectURL(
        	document.getElementById('files').files[0]
    	);
}

function updatePosition(e) {
  function updateCoord(pos, delta, max) {
    pos += delta;
    if (pos > max) {
	pos = max;
    }
    if (pos < 0) {
      pos = 0;
    }
    return pos;
  }

  x = updateCoord(x, e.movementX /2, canvas.width);
  y = updateCoord(y, e.movementY /2, canvas.height);
  
  tracker.textContent = `X position: ${x}, Y position: ${y}`;

  canvasDraw();
}

function score() {
	if (pwidth.length == 0) return;

	zoom();
	setTimeout(recognize, 1000);
}

function recognize() {

	var imgData = ctx.getImageData(0,0,canvas.width,canvas.height);
	var pix = imgData.data;

	var bestScore = 0;
	var bestI = 0;
	for (var i = 0; i < pwidth.length; i++) {
		var bpix = ppix[i];
		var bw = pwidth[i];
		var p = 3;
		var score = 0;
		for (var y = 0; y < SIZE; y++) {
			for (var x = 0; x < canvas.width; x++, p += 4) {
				if (pix[p] != 0) {
					for (var dy = -SIZE; dy <= SIZE; dy++) {
						if (y + dy < 0) continue;
						if (y + dy >= SIZE) continue;

						var pp = (y + dy) * bw + x;
						var pi = bpix[pp*4+3];
						if (pi == pix[p]) {
							score += SIZE - Math.abs(dy);
						}
					}
					for (var dx = -SIZE; dx <= SIZE; dx++) {
						if (x + dx < 0) continue;
						if (x + dx >= canvas.width) continue;

						var pp = y * bw + (x + dx);
						var pi = bpix[pp*4+3];
						if (pi == pix[p]) {
							score += SIZE - Math.abs(dx);
						}
					}
				}
			}
		}
		console.log(i + " score: " + score);
		if (score > bestScore) {
			bestI = i;
			bestScore = score;
		}
	}
	storage.innerHTML = "Best find: " + bestI + " out of " + pwidth.length;
}

